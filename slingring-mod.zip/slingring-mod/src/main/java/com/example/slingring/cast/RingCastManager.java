package com.example.slingring.cast;

import com.example.slingring.SlingRingMod;
import net.minecraft.core.BlockPos;
import net.minecraft.core.particles.DustParticleOptions;
import net.minecraft.core.particles.ParticleOptions;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.phys.Vec3;
import net.minecraft.world.level.levelgen.Heightmap;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.event.server.ServerStoppingEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;
import org.joml.Vector3f;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

/**
 * Runs the ~2 second "sling ring" animation (a swirling golden ring in front of the player)
 * and teleports the player to the village at the end.
 * All state is touched on the server thread only.
 */
@Mod.EventBusSubscriber(modid = SlingRingMod.MOD_ID)
public final class RingCastManager {
    public static final int CAST_TICKS = 40;

    private static final DustParticleOptions GOLD =
            new DustParticleOptions(new Vector3f(1.0F, 0.78F, 0.12F), 1.1F);
    private static final DustParticleOptions BRIGHT_GOLD =
            new DustParticleOptions(new Vector3f(1.0F, 0.92F, 0.45F), 1.4F);

    private static final List<Cast> CASTS = new ArrayList<>();

    private static final class Cast {
        final ServerPlayer player;
        final BlockPos village;
        int age;

        Cast(ServerPlayer player, BlockPos village) {
            this.player = player;
            this.village = village;
        }
    }

    private RingCastManager() {}

    public static boolean isCasting(ServerPlayer player) {
        for (Cast cast : CASTS) {
            if (cast.player == player) {
                return true;
            }
        }
        return false;
    }

    public static void start(ServerPlayer player, BlockPos village) {
        if (isCasting(player)) {
            return;
        }
        CASTS.add(new Cast(player, village));
        player.serverLevel().playSound(null, player.blockPosition(),
                SoundEvents.PORTAL_TRIGGER, SoundSource.PLAYERS, 0.5F, 1.4F);
    }

    @SubscribeEvent
    public static void onServerTick(TickEvent.ServerTickEvent event) {
        if (event.phase != TickEvent.Phase.END || CASTS.isEmpty()) {
            return;
        }
        Iterator<Cast> it = CASTS.iterator();
        while (it.hasNext()) {
            Cast cast = it.next();
            ServerPlayer player = cast.player;
            if (!player.isAlive()) {
                it.remove();
                continue;
            }
            ServerLevel level = player.serverLevel();
            spawnRing(level, player, cast.age);
            cast.age++;
            if (cast.age >= CAST_TICKS) {
                teleport(level, player, cast.village);
                it.remove();
            }
        }
    }

    @SubscribeEvent
    public static void onServerStopping(ServerStoppingEvent event) {
        CASTS.clear();
    }

    private static void spawnRing(ServerLevel level, ServerPlayer player, int age) {
        Vec3 look = player.getLookAngle();
        Vec3 forward = new Vec3(look.x, 0.0, look.z);
        if (forward.lengthSqr() < 1.0E-4) {
            forward = new Vec3(0.0, 0.0, 1.0);
        }
        forward = forward.normalize();
        Vec3 right = new Vec3(-forward.z, 0.0, forward.x);
        Vec3 center = player.position().add(0.0, 1.1, 0.0).add(forward.scale(1.8));

        double radius = 0.5 + 0.9 * Math.min(1.0, age / 12.0);

        // Full faint ring (every other tick to save bandwidth)
        if (age % 2 == 0) {
            int points = 32;
            for (int i = 0; i < points; i++) {
                double a = (Math.PI * 2.0) * i / points;
                point(level, GOLD, center, right, radius, a);
            }
        }

        // Spinning bright sparks with a short trail (the "swirl")
        int heads = 6;
        for (int i = 0; i < heads; i++) {
            double a = age * 0.45 + (Math.PI * 2.0) * i / heads;
            point(level, ParticleTypes.FLAME, center, right, radius, a);
            for (int t = 1; t <= 3; t++) {
                point(level, BRIGHT_GOLD, center, right, radius, a - t * 0.14);
            }
        }

        // Counter-rotating inner ring
        double inner = radius * 0.6;
        for (int i = 0; i < 4; i++) {
            double a = -age * 0.6 + (Math.PI * 2.0) * i / 4.0;
            point(level, GOLD, center, right, inner, a);
        }

        if (age % 10 == 0) {
            level.playSound(null, player.blockPosition(),
                    SoundEvents.AMETHYST_BLOCK_CHIME, SoundSource.PLAYERS, 0.8F, 0.8F + age * 0.02F);
        }
    }

    private static void point(ServerLevel level, ParticleOptions particle, Vec3 center, Vec3 right,
                              double radius, double angle) {
        double x = center.x + right.x * Math.cos(angle) * radius;
        double y = center.y + Math.sin(angle) * radius;
        double z = center.z + right.z * Math.cos(angle) * radius;
        level.sendParticles(particle, x, y, z, 1, 0.0, 0.0, 0.0, 0.0);
    }

    private static void teleport(ServerLevel level, ServerPlayer player, BlockPos village) {
        burst(level, player.position().add(0.0, 1.0, 0.0));
        level.playSound(null, player.blockPosition(),
                SoundEvents.ENDERMAN_TELEPORT, SoundSource.PLAYERS, 1.0F, 0.9F);

        // Make sure the destination chunk is loaded, then find the surface
        level.getChunk(village.getX() >> 4, village.getZ() >> 4);
        int y = level.getHeight(Heightmap.Types.MOTION_BLOCKING_NO_LEAVES, village.getX(), village.getZ());
        double x = village.getX() + 0.5;
        double z = village.getZ() + 0.5;

        player.fallDistance = 0.0F;
        player.teleportTo(level, x, y, z, player.getYRot(), player.getXRot());

        burst(level, new Vec3(x, y + 1.0, z));
        level.playSound(null, BlockPos.containing(x, y, z),
                SoundEvents.ENDERMAN_TELEPORT, SoundSource.PLAYERS, 1.0F, 1.1F);
    }

    private static void burst(ServerLevel level, Vec3 pos) {
        for (int i = 0; i < 60; i++) {
            double theta = Math.random() * Math.PI * 2.0;
            double phi = Math.acos(2.0 * Math.random() - 1.0);
            double dx = Math.sin(phi) * Math.cos(theta);
            double dy = Math.cos(phi);
            double dz = Math.sin(phi) * Math.sin(theta);
            level.sendParticles(ParticleTypes.FLAME, pos.x, pos.y, pos.z, 0, dx, dy, dz, 0.25);
        }
        for (int i = 0; i < 20; i++) {
            level.sendParticles(BRIGHT_GOLD,
                    pos.x + (Math.random() - 0.5), pos.y + (Math.random() - 0.5), pos.z + (Math.random() - 0.5),
                    1, 0.0, 0.0, 0.0, 0.0);
        }
    }
}
