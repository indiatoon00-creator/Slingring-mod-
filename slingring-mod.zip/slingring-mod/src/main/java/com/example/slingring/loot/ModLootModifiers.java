package com.example.slingring.loot;

import com.example.slingring.SlingRingMod;
import com.mojang.serialization.Codec;
import net.minecraftforge.common.loot.IGlobalLootModifier;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

public final class ModLootModifiers {
    public static final DeferredRegister<Codec<? extends IGlobalLootModifier>> LOOT_MODIFIERS =
            DeferredRegister.create(ForgeRegistries.Keys.GLOBAL_LOOT_MODIFIER_SERIALIZERS, SlingRingMod.MOD_ID);

    public static final RegistryObject<Codec<? extends IGlobalLootModifier>> RING_DROP =
            LOOT_MODIFIERS.register("ring_drop", RingDropModifier.CODEC);

    private ModLootModifiers() {}
}
