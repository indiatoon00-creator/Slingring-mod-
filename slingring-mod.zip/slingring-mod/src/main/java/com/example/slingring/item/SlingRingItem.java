package com.example.slingring.item;

import com.example.slingring.cast.RingCastManager;
import net.minecraft.core.BlockPos;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.tags.StructureTags;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResultHolder;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.TooltipFlag;
import net.minecraft.world.level.Level;

import javax.annotation.Nullable;
import java.util.List;

public class SlingRingItem extends Item {
    /** Search radius in chunks (same idea as /locate). */
    private static final int SEARCH_RADIUS_CHUNKS = 100;
    private static final int COOLDOWN_TICKS = 20 * 30;
    private static final int FAIL_COOLDOWN_TICKS = 20 * 5;

    public SlingRingItem(Properties properties) {
        super(properties);
    }

    @Override
    public InteractionResultHolder<ItemStack> use(Level level, Player player, InteractionHand hand) {
        ItemStack stack = player.getItemInHand(hand);

        if (level.isClientSide) {
            return InteractionResultHolder.success(stack);
        }

        ServerPlayer serverPlayer = (ServerPlayer) player;
        ServerLevel serverLevel = (ServerLevel) level;

        if (RingCastManager.isCasting(serverPlayer)) {
            return InteractionResultHolder.fail(stack);
        }

        if (serverLevel.dimension() != Level.OVERWORLD) {
            serverPlayer.displayClientMessage(Component.translatable("message.slingring.wrong_dimension"), true);
            return InteractionResultHolder.fail(stack);
        }

        // Note: this search runs on the server thread and can take a moment in unexplored terrain.
        BlockPos village = serverLevel.findNearestMapStructure(
                StructureTags.VILLAGE, serverPlayer.blockPosition(), SEARCH_RADIUS_CHUNKS, false);

        if (village == null) {
            serverPlayer.displayClientMessage(Component.translatable("message.slingring.no_village"), true);
            serverPlayer.getCooldowns().addCooldown(this, FAIL_COOLDOWN_TICKS);
            return InteractionResultHolder.fail(stack);
        }

        int distance = (int) Math.sqrt(serverPlayer.blockPosition().distSqr(
                new BlockPos(village.getX(), serverPlayer.getBlockY(), village.getZ())));
        serverPlayer.displayClientMessage(
                Component.translatable("message.slingring.casting", distance), true);

        serverPlayer.getCooldowns().addCooldown(this, COOLDOWN_TICKS);
        RingCastManager.start(serverPlayer, village);
        return InteractionResultHolder.consume(stack);
    }

    @Override
    public void appendHoverText(ItemStack stack, @Nullable Level level, List<Component> tooltip, TooltipFlag flag) {
        tooltip.add(Component.translatable("tooltip.slingring.sling_ring"));
    }
}
