package com.example.slingring.loot;

import com.example.slingring.item.ModItems;
import com.google.common.base.Suppliers;
import com.mojang.serialization.Codec;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import it.unimi.dsi.fastutil.objects.ObjectArrayList;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.enchantment.EnchantmentHelper;
import net.minecraft.world.item.enchantment.Enchantments;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.storage.loot.LootContext;
import net.minecraft.world.level.storage.loot.parameters.LootContextParams;
import net.minecraft.world.level.storage.loot.predicates.LootItemCondition;
import net.minecraftforge.common.loot.LootModifier;

import java.util.function.Supplier;

/**
 * Adds a Sling Ring to the drops when a player mines stone or deepslate.
 * The chance is configured in data/slingring/loot_modifiers/ring_drop.json.
 */
public class RingDropModifier extends LootModifier {
    public static final Supplier<Codec<RingDropModifier>> CODEC = Suppliers.memoize(() ->
            RecordCodecBuilder.create(inst -> codecStart(inst)
                    .and(Codec.FLOAT.fieldOf("chance").forGetter(m -> m.chance))
                    .apply(inst, RingDropModifier::new)));

    private final float chance;

    public RingDropModifier(LootItemCondition[] conditions, float chance) {
        super(conditions);
        this.chance = chance;
    }

    @Override
    protected ObjectArrayList<ItemStack> doApply(ObjectArrayList<ItemStack> generatedLoot, LootContext context) {
        BlockState state = context.getParamOrNull(LootContextParams.BLOCK_STATE);
        if (state == null || !(state.is(Blocks.STONE) || state.is(Blocks.DEEPSLATE))) {
            return generatedLoot;
        }
        // Only when a player breaks it (no pistons, explosions, etc.)
        if (!(context.getParamOrNull(LootContextParams.THIS_ENTITY) instanceof Player)) {
            return generatedLoot;
        }
        // No silk-touch farming
        ItemStack tool = context.getParamOrNull(LootContextParams.TOOL);
        if (tool != null && EnchantmentHelper.getTagEnchantmentLevel(Enchantments.SILK_TOUCH, tool) > 0) {
            return generatedLoot;
        }
        if (context.getRandom().nextFloat() < chance) {
            generatedLoot.add(new ItemStack(ModItems.SLING_RING.get()));
        }
        return generatedLoot;
    }

    @Override
    public Codec<? extends net.minecraftforge.common.loot.IGlobalLootModifier> codec() {
        return CODEC.get();
    }
}
