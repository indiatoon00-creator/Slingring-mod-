# Sling Ring (Forge 1.20.1)

A Doctor Strange-style Sling Ring.

- **Drop:** ~0.3% chance when a player mines stone or deepslate (not with Silk Touch).
  Change the chance in `src/main/resources/data/slingring/loot_modifiers/ring_drop.json`.
- **Use:** right-click. A swirling golden ring opens in front of you for 2 seconds,
  then you are teleported to the nearest village (Overworld only, 30 second cooldown).
- Give yourself one for testing: `/give @s slingring:sling_ring`

## Build

    gradle wrapper --gradle-version 8.8   # once, optional
    ./gradlew build                        # jar in build/libs/
    ./gradlew runClient                    # test in game

Every push and pull request is also compiled automatically by GitHub Actions
(`.github/workflows/build.yml`). The built jar is attached to the run under **Artifacts**.
You can also run it by hand from the repo's **Actions** tab -> **Compile** -> **Run workflow**.

## Publish to CurseForge (automatic)

1. CurseForge For Authors -> Account -> API Tokens -> Generate Token (copied once!).
2. GitHub repo -> Settings -> Secrets and variables -> Actions:
   - Secret   `CURSEFORGE_TOKEN`       = your token
   - Variable `CURSEFORGE_PROJECT_ID`  = the number under "About Project" on your CurseForge project
3. Release:

       git tag v1.0.0
       git push origin v1.0.0

Where things are configured (build.gradle, `publishMods {}`):
mod loader = `modLoaders.add("forge")`, Minecraft version = `minecraftVersions.add(...)`,
dependencies = `requires("slug")`, release type = tag suffix (`-beta`, `-alpha`),
release notes = commit messages since the previous tag.
Upload your very first file manually once the project is approved, then let the pipeline handle the rest.
